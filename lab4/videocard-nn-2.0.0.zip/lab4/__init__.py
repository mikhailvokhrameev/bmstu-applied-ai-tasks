"""Compatibility namespace; implementation files have a single canonical copy."""
from pathlib import Path
_root = Path(__file__).resolve().parent.parent
__path__ = [str(_root), str(_root / "docs")]
